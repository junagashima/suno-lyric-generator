'use client'

import { useState } from 'react'
import { SongGeneratorForm } from '@/components/SongGeneratorForm'
import { ResultDisplay } from '@/components/ResultDisplay'
import { EditableResultDisplay } from '@/components/EditableResultDisplay'
import { GuideSection } from '@/components/GuideSection'
import { FAQSection } from '@/components/FAQSection'

export default function Home() {
  const [generatedData, setGeneratedData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  return (
    <main className="container mx-auto px-4 py-8 max-w-6xl">
      {/* ヘッダー */}
      <header className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          🎵 Suno AI 歌詞・スタイル生成ツール
        </h1>
        <p className="text-lg text-gray-600 max-w-3xl mx-auto">
          AIを活用してSuno AIで使用する歌詞とスタイル指示を生成します。<br/>
          簡単モードまたはこだわりモードで、あなたの楽曲制作をサポートします。
        </p>
      </header>

      {/* メインコンテンツ */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* 左側: 入力フォーム */}
        <div>
          <SongGeneratorForm 
            onGenerate={setGeneratedData}
            setIsLoading={setIsLoading}
            isLoading={isLoading}
          />
        </div>

        {/* 右側: 結果表示 */}
        <div>
          {generatedData?.editableStyle ? (
            <EditableResultDisplay 
              data={generatedData}
              isLoading={isLoading}
            />
          ) : (
            <ResultDisplay 
              data={generatedData}
              isLoading={isLoading}
            />
          )}
        </div>
      </div>

      {/* 説明・FAQ セクション */}
      <div className="mt-16 space-y-12">
        <GuideSection />
        <FAQSection />
      </div>
    </main>
  )
}